// CS2 $20 Draft — online room server for Cloudflare Workers.
// The page (public/index.html) is served as static assets.
// /ws?room=CODE opens a WebSocket into one Durable Object per room code.
// The room only relays messages between the players in it; the host's browser runs the game.
import { DurableObject } from "cloudflare:workers";

const MAX_PEERS = 4;          // host + guest, plus a little slack for reconnects
const MAX_MSG_BYTES = 8192;   // game state is ~2 KB

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === "/ws") {
      if (request.headers.get("Upgrade") !== "websocket") {
        return new Response("Expected a WebSocket upgrade", { status: 426 });
      }
      const code = (url.searchParams.get("room") || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
      if (code.length !== 4) return new Response("Bad room code", { status: 400 });
      const stub = env.ROOMS.get(env.ROOMS.idFromName(code));
      return stub.fetch(request);
    }
    return env.ASSETS.fetch(request);
  },
};

export class DraftRoom extends DurableObject {
  async fetch(request) {
    const open = this.ctx.getWebSockets();
    if (open.length >= MAX_PEERS) {
      // drop the oldest socket so a player who reconnects is never locked out
      try { open[0].close(4000, "replaced"); } catch (e) {}
    }
    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);
    this.ctx.acceptWebSocket(server);
    return new Response(null, { status: 101, webSocket: client });
  }

  async webSocketMessage(ws, message) {
    if (typeof message !== "string" || message.length > MAX_MSG_BYTES) return;
    for (const peer of this.ctx.getWebSockets()) {
      if (peer === ws) continue;
      try { peer.send(message); } catch (e) {}
    }
  }

  async webSocketClose(ws, code, reason) {
    try { ws.close(1000, "bye"); } catch (e) {}
  }

  async webSocketError(ws) {
    try { ws.close(1011, "error"); } catch (e) {}
  }
}
