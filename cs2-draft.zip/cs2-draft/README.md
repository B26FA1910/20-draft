# CS2 $20 Draft

CS2-ийн тамирчдаар баг бүрдүүлэх «$20 draft» дуудлага худалдааны тоглоом. Мөнгө нь виртуал.

## Файлууд

- `public/index.html`: тоглоом бүхэлдээ энэ нэг файлд байна (компьютерын эсрэг, 2 хүн нэг утсан дээр, онлайн)
- `src/worker.js`: онлайн өрөөний сервер (Cloudflare Worker + Durable Object)
- `wrangler.jsonc`: Cloudflare-ийн тохиргоо

## Cloudflare дээр байршуулах (GitHub → Cloudflare)

1. GitHub дээр шинэ repo үүсгэ (жишээ нь `cs2-draft`). Энэ хавтасны файлуудыг бүтэц хэвээр нь upload хий:
   `wrangler.jsonc`, `src/worker.js`, `public/index.html`.
2. Cloudflare Dashboard → **Workers & Pages** → **Create** → **Import a repository** руу ороод repo-гоо сонго.
3. Build command хоосон, Deploy command `npx wrangler deploy` хэвээр үлдээгээд **Deploy** дар.
4. `https://cs2-draft.<таны-subdomain>.workers.dev` хаяг гарна. Онлайн горим энэ хаяг дээр ажиллана.

Durable Objects нь Workers Free план дээр SQLite storage-тэйгээр үнэгүй ажилладаг. `wrangler.jsonc` дотор аль хэдийн тохируулсан.

## Онлайн хэрхэн ажилладаг вэ

- Хост өрөө үүсгэхэд 4 тэмдэгттэй код гарна. Найз нь «Онлайн → Нэгдэх» хэсэгт кодыг оруулна, эсвэл `.../#room-КОД` холбоосоор шууд орж ирнэ.
- Хостын браузер тоглолтыг удирдана (цаг, автомат сонголт, тоглолтын үр дүн). Сервер зөвхөн мессеж дамжуулна.
- Ялалт, ялагдлын тоо тоглогч бүрийн өөрийн төхөөрөмж дээр (localStorage) хадгалагдана.
